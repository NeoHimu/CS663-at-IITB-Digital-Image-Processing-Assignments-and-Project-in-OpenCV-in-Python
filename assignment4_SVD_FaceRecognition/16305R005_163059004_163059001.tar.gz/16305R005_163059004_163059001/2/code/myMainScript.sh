#[2, 10, 20, 50, 75, 100, 125, 150, 175]
# For reconstruction of image
#gnome-terminal -e "python 2.py 2"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 10"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 20"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 50"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 75"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 100"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 125"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 150"
#read -p "Press any key to continue... " -n1 -s

#gnome-terminal -e "python 2.py 175"
#read -p "Press any key to continue... " -n1 -s

# For first 25 eigen faces

gnome-terminal -e "python 2.py 1000 0"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 1"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 2"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 3"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 4"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 5"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 6"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 7"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 8"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 9"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 10"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 11"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 12"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 13"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 14"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 15"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 16"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 17"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 18"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 19"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 20"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 21"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 22"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 23"
read -p "Press any key to continue... " -n1 -s

gnome-terminal -e "python 2.py 1000 24"
read -p "Press any key to continue... " -n1 -s


